using UnityEngine;

public class PortaVitoria : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        
        if (collision.CompareTag("Player"))
        {
            
            if (GameManager.instancia != null && GameManager.instancia.moedasAtuais >= 1)
            {
                Debug.Log("VOCÊ VENCEU O JOGO!");
                
            }
            else
            {
                Debug.Log("A porta está trancada! Você precisa pegar a moeda primeiro.");
            }
        }
    }
}
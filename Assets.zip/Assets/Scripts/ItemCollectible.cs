using UnityEngine;

public class ItemCollectible : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            if (GameManager.instancia != null)
            {
                GameManager.instancia.GanharMoeda();
            }
            
            Destroy(gameObject);
        }
    }
}
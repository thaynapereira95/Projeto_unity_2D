using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float velocidade = 5f;
    public float forcaPulo = 10f;
    
    private Rigidbody2D rb;
    private Animator anim;
    private SpriteRenderer sprite;
    private bool estaNoChao;
    private bool pertoDaEscada;
    private bool escalando;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>(); 
        sprite = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        
        float h = Input.GetAxisRaw("Horizontal");
        
        float velAtual = velocidade;
        if (Input.GetKey(KeyCode.LeftShift))
        {
            velAtual = velocidade * 1.5f; 
        }

        rb.linearVelocity = new Vector2(h * velAtual, rb.linearVelocity.y);

        
        if (h > 0) sprite.flipX = false;
        else if (h < 0) sprite.flipX = true;

       
        if (Input.GetButtonDown("Jump") && estaNoChao)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0); 
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, forcaPulo);
            estaNoChao = false; 
        }

       
        float v = Input.GetAxisRaw("Vertical");
        if (pertoDaEscada && Mathf.Abs(v) > 0)
        {
            escalando = true;
        }

        if (escalando)
        {
            rb.gravityScale = 0;
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, v * velocidade);
        }
        else
        {
            rb.gravityScale = 3; 
        }

        
        if (anim != null && anim.runtimeAnimatorController != null)
        {
            anim.SetFloat("Speed", Mathf.Abs(h));
            anim.SetBool("isGrounded", estaNoChao);
            anim.SetBool("isClimbing", escalando);
        }
    }

    
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Chao"))
        {
            estaNoChao = true;
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Chao"))
        {
            estaNoChao = true;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Chao"))
        {
            estaNoChao = false;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Ladder")) pertoDaEscada = true;
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Ladder"))
        {
            pertoDaEscada = false;
            escalando = false;
        }
    }

    public void Morrer()
    {
        GameManager.instancia.GameOver();
    }
}
using UnityEngine;
using UnityEngine.SceneManagement; 

public class MenuGerente : MonoBehaviour
{
    public void IniciarJogo()
    {
        
       SceneManager.LoadScene("SampleScene"); // 
    }
}
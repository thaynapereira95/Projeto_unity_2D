using UnityEngine;

public class Inimigo : MonoBehaviour
{
    public float velocidade = 2f;
    public float tempoDePatrulha = 2f; 
    
    private float cronometro;
    private bool andandoParaEsquerda = true;
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        if (rb == null) rb = gameObject.AddComponent<Rigidbody2D>(); 
        
        rb.gravityScale = 0;
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        cronometro = tempoDePatrulha;
    }

    void Update()
    {
        cronometro -= Time.deltaTime;

        if (cronometro <= 0)
        {
            andandoParaEsquerda = !andandoParaEsquerda;
            cronometro = tempoDePatrulha; 
        }

        if (andandoParaEsquerda)
        {
            rb.linearVelocity = new Vector2(-velocidade, rb.linearVelocity.y);
            transform.localScale = new Vector3(1, 1, 1);
        }
        else
        {
            rb.linearVelocity = new Vector2(velocidade, rb.linearVelocity.y);
            transform.localScale = new Vector3(-1, 1, 1);
        }
    }

   
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            
            Vector2 pontoDeContato = collision.contacts[0].normal;

            
            if (pontoDeContato.y < -0.5f)
            {
                
                Rigidbody2D playerRb = collision.gameObject.GetComponent<Rigidbody2D>();
                if (playerRb != null)
                {
                    playerRb.linearVelocity = new Vector2(playerRb.linearVelocity.x, 7f); 
                }

                
                Destroy(gameObject);
            }
            else
            {
                
                PlayerController player = collision.gameObject.GetComponent<PlayerController>();
                if (player != null) player.Morrer();
            }
        }
    }
}
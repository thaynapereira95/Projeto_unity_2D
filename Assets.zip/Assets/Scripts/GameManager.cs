using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instancia;
    public int moedasAtuais = 0;

    public GameObject telaVitoria; 
    
    
    public float tempoDeEspera = 3f; 

    private void Awake()
    {
        if (instancia == null)
        {
            instancia = this;
        }
    }

    private void Start()
    {
        if (telaVitoria != null) telaVitoria.SetActive(false);
        Time.timeScale = 1f;
    }

    public void GanharMoeda()
    {
        moedasAtuais++;
        
        HUDManager hud = GetComponent<HUDManager>();
        if (hud != null)
        {
            hud.AtualizarPlacar(moedasAtuais);
        }
    }

    public void GameOver()
    {
        Debug.Log("O Mario morreu! Reiniciando a fase...");
        Time.timeScale = 1f;
        string faseAtual = SceneManager.GetActiveScene().name;
        SceneManager.LoadScene(faseAtual);
    }

   
    public void VencerJogo()
    {
        Debug.Log("Você venceu a fase! Mostrando a tela de vitória...");
        
        if (telaVitoria != null)
        {
            telaVitoria.SetActive(true);
            
           
            StartCoroutine(EsperarEMudarDeFase()); 
        }
        else
        {
           
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }

    
    private IEnumerator EsperarEMudarDeFase()
    {
        
        yield return new WaitForSeconds(tempoDeEspera);
        
       
        int faseAtual = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(faseAtual + 1);
    }
}
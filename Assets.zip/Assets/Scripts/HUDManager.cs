using UnityEngine;
using UnityEngine.UI;

public class HUDManager : MonoBehaviour
{
    public Text textoMoedas;

    public void AtualizarPlacar(int quantidadeMoedas)
    {
        if (textoMoedas != null)
        {
            textoMoedas.text = "Moedas: " + quantidadeMoedas;
        }
    }
}